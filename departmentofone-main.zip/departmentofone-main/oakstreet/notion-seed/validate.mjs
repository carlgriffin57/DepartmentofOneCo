/*
 * Checks the seed CSVs before they go into Notion.
 *
 *   node notion-seed/validate.mjs
 *
 * Notion fails quietly on import: an unrecognised select option is dropped and
 * a relation whose target title does not match exactly lands empty. Both look
 * like the import "worked". This catches those before you spend the time.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

// Must match the demo form's option values character for character.
const PROGRAMS = [
  'Puppy Foundation', 'Basic Obedience', 'Behavior Correction',
  'In-Home Private', 'Group Classes', 'Board & Train', 'Not sure yet',
];

let fails = 0;
const fail = (m) => { console.log(`  FAIL  ${m}`); fails++; };

/* Minimal RFC4180 parser — handles quoted fields containing commas. */
function parseCsv(text) {
  const rows = [];
  let row = [], field = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') quoted = false;
      else field += c;
    } else if (c === '"') quoted = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
    else if (c !== '\r') field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  const header = rows.shift();
  return rows.filter((r) => r.some((v) => v !== ''))
    .map((r) => Object.fromEntries(header.map((h, i) => [h, (r[i] ?? '').trim()])));
}

const load = (f) => parseCsv(fs.readFileSync(path.join(HERE, f), 'utf8'));

const owners = load('01-owners.csv');
const dogs = load('02-dogs.csv');
const sessions = load('03-sessions.csv');
const requests = load('04-booking-requests.csv');

console.log(`\nowners ${owners.length} · dogs ${dogs.length} · sessions ${sessions.length} · requests ${requests.length}\n`);

console.log('=== Select options match the form exactly ===');
for (const [file, rows, col] of [
  ['02-dogs.csv', dogs, 'Program'],
  ['03-sessions.csv', sessions, 'Type'],
  ['04-booking-requests.csv', requests, 'Program'],
]) {
  for (const r of rows) {
    if (!PROGRAMS.includes(r[col])) fail(`${file}: "${r[col]}" is not one of the seven program names`);
  }
}
for (const [file, rows, col, allowed] of [
  ['02-dogs.csv', dogs, 'Status', ['Active', 'Completed', 'Paused']],
  ['03-sessions.csv', sessions, 'Status', ['Scheduled', 'Completed', 'No-show']],
  ['04-booking-requests.csv', requests, 'Status', ['New', 'Contacted', 'Booked']],
]) {
  for (const r of rows) {
    if (!allowed.includes(r[col])) fail(`${file}: Status "${r[col]}" not in ${allowed.join(' / ')}`);
  }
}

console.log('\n=== Relations resolve by title ===');
{
  const ownerNames = new Set(owners.map((o) => o.Name));
  for (const d of dogs) {
    if (!ownerNames.has(d.Owner)) fail(`02-dogs.csv: "${d.Name}" points at owner "${d.Owner}", who is not in 01-owners.csv`);
  }
  const dogNames = new Set(dogs.map((d) => d.Name));
  for (const s of sessions) {
    if (!dogNames.has(s.Dog)) fail(`03-sessions.csv: "${s.Session}" points at dog "${s.Dog}", who is not in 02-dogs.csv`);
  }
}

console.log('\n=== Titles are unique (duplicates break relation matching) ===');
for (const [file, rows, col] of [
  ['01-owners.csv', owners, 'Name'],
  ['02-dogs.csv', dogs, 'Name'],
  ['03-sessions.csv', sessions, 'Session'],
]) {
  const seen = new Set(), dupes = new Set();
  for (const r of rows) { if (seen.has(r[col])) dupes.add(r[col]); seen.add(r[col]); }
  for (const d of dupes) fail(`${file}: duplicate title "${d}"`);
}

console.log('\n=== Dates are ISO (YYYY-MM-DD) ===');
for (const [file, rows, col] of [['03-sessions.csv', sessions, 'Date'], ['04-booking-requests.csv', requests, 'Received']]) {
  for (const r of rows) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(r[col])) fail(`${file}: "${r[col]}" is not YYYY-MM-DD`);
    else if (Number.isNaN(Date.parse(r[col]))) fail(`${file}: "${r[col]}" is not a real date`);
  }
}

console.log('\n=== Contact fields are well formed and clearly fictional ===');
for (const [file, rows] of [['01-owners.csv', owners], ['04-booking-requests.csv', requests]]) {
  for (const r of rows) {
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(r.Email)) fail(`${file}: "${r.Email}" is not a valid email`);
    // example.com is reserved for documentation — seed data must never reach a real inbox.
    if (!/@example\.com$/i.test(r.Email)) fail(`${file}: "${r.Email}" is not on example.com`);
    if (!/^210-555-\d{4}$/.test(r.Phone)) fail(`${file}: "${r.Phone}" should be 210-555-XXXX`);
  }
}

console.log(`\n${fails === 0 ? 'PASS' : 'FAIL'} — ${fails} problem(s)\n`);
process.exit(fails ? 1 : 0);
