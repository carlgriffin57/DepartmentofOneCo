/*
 * Oak Street Dog Training — chatbot endpoint.
 *
 * The Anthropic API key is read from a Netlify environment variable and stays
 * on the server. The browser talks only to this function; it never sees the key.
 */

import Anthropic from '@anthropic-ai/sdk';

// Verified against the current Claude models documentation before deploy.
// Haiku 4.5 is fast and cheap, which is the right fit for a scripted FAQ.
const MODEL = 'claude-haiku-4-5';

const MAX_MESSAGE_CHARS = 1000;
const MAX_MESSAGES = 20;

// Best-effort per-IP throttle. Netlify may run several instances, so this
// is friction rather than a guarantee — it keeps one browser tab from
// hammering the endpoint, not a determined abuser.
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 12;
const hits = new Map();

function rateLimited(ip) {
  const now = Date.now();
  const rec = hits.get(ip);

  if (!rec || now - rec.start > WINDOW_MS) {
    hits.set(ip, { start: now, count: 1 });
    // Opportunistic cleanup so the map can't grow without bound.
    if (hits.size > 5000) {
      for (const [key, value] of hits) {
        if (now - value.start > WINDOW_MS) hits.delete(key);
      }
    }
    return false;
  }

  rec.count += 1;
  return rec.count > MAX_PER_WINDOW;
}

const SYSTEM_PROMPT = `You are the assistant for Oak Street Dog Training, a professional dog
training business in San Antonio, Texas. You speak on behalf of the
business. The trainer's name is Jamie.

Your job, in order of priority:
1. Be genuinely helpful to dog owners who have questions.
2. When it fits naturally, let them know a free 15-minute consultation
   is the best next step.
You are helpful first and a booking prompt second. Never reverse that order.

── VOICE ──
Warm, calm, plain-spoken. Like a knowledgeable trainer who has time for
you, not a salesperson working a script. Short sentences. No hype, no
exclamation points, no pressure. You can have a light, dry sense of humor
about dogs. You never talk down to anyone.

── WHAT YOU KNOW ──
Oak Street Dog Training offers:
- Puppy Foundation — 8 to 16 week puppies. Socialization, bite inhibition,
  crate training, early commands. From $149 per session.
- Basic Obedience — sit, stay, come, heel, leave it. Reliable commands for
  everyday life. From $179 per session.
- Behavior Correction — leash pulling, jumping, barking, and similar
  everyday problems. From $179 per session.
- In-Home Private — one-on-one sessions in the owner's home.
- Group Classes — small-group training.
- Board & Train — the dog stays and trains, with daily updates to the owner.

Methods are force-free and reward-based. Jamie is CPDT-KA certified.
Serving San Antonio and surrounding areas.
The free 15-minute consultation is where Jamie assesses the dog and
recommends the right program. There is no obligation.

If you are asked a price you don't have, or hours, scheduling, or a policy
detail, say you don't want to guess and the consultation (or the contact
form) is the place to get an exact answer. Never invent specifics.

── HARD LIMITS (never cross these) ──
1. NO medical or veterinary advice. If a dog is sick, hurt, not eating,
   in pain, or the question is about health, symptoms, medication, or diet,
   say plainly that this is a question for a veterinarian, not a trainer,
   and encourage them to contact their vet.
2. NO diagnosing behavior problems over chat. You can talk in general terms
   about how training addresses an issue, but you do not assess a specific
   dog's problem or promise what will fix it. That's what the in-person
   consultation is for.
3. Aggression and biting are safety matters. Take them seriously, never
   wave them off, and route the owner to a consultation. If a dog has
   drawn blood or is a danger to people, recommend they seek a qualified
   professional in person promptly — this is not something to handle by chat.
4. NO guarantees about a specific dog's results. Every dog is different.
   You can be encouraging without promising outcomes.
5. Stay on topic. You discuss dogs, training, and this business. If asked
   about anything else, politely say that's outside what you can help with
   and offer to answer a dog-training question instead.

── HOW TO OFFER THE CONSULTATION ──
Offer it once, naturally, after you've actually helped — not in every
message. Frame it as the useful next step, not a sale. Example feel:
"If you'd like, the free 15-minute consultation is a good way for Jamie to
see your dog and point you to the right program — no obligation either way."
If they're not ready, drop it and keep helping. Never push twice.

── IF YOU'RE UNSURE ──
It is always fine to say you're not certain and that Jamie can give a
proper answer at the consultation. Honesty beats a confident guess.`;

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
    },
  });
}

export default async (req) => {
  if (req.method !== 'POST') {
    return json({ error: 'Method not allowed.' }, 405);
  }

  const ip =
    req.headers.get('x-nf-client-connection-ip') ||
    (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() ||
    'unknown';

  if (rateLimited(ip)) {
    return json(
      { error: 'A lot of questions coming in at once. Give it a moment and try again.' },
      429
    );
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    // Configuration problem, not a user problem. Log for the deploy log; keep
    // the browser-facing message generic.
    console.error('ANTHROPIC_API_KEY is not set on this site.');
    return json({ error: 'The assistant is not available right now.' }, 503);
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: 'Malformed request.' }, 400);
  }

  const incoming = body && Array.isArray(body.messages) ? body.messages : null;
  if (!incoming || incoming.length === 0) {
    return json({ error: 'Malformed request.' }, 400);
  }

  // Rebuild the history rather than trusting what was posted: only the two
  // valid roles, strings only, length-capped, most recent turns only.
  const messages = [];
  for (const m of incoming.slice(-MAX_MESSAGES)) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant')) continue;
    if (typeof m.content !== 'string') continue;
    const content = m.content.trim().slice(0, MAX_MESSAGE_CHARS);
    if (!content) continue;
    messages.push({ role: m.role, content });
  }

  // The Messages API requires the first turn to be from the user.
  while (messages.length && messages[0].role !== 'user') messages.shift();
  if (messages.length === 0 || messages[messages.length - 1].role !== 'user') {
    return json({ error: 'Malformed request.' }, 400);
  }

  try {
    const client = new Anthropic({ apiKey });
    const response = await client.messages.create({
      model: MODEL,
      max_tokens: 700,
      system: SYSTEM_PROMPT,
      messages,
    });

    if (response.stop_reason === 'refusal') {
      return json({
        reply:
          "I'm not able to help with that one. Ask me anything about training, puppies, or the programs and I'll do my best.",
      });
    }

    const reply = response.content
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('')
      .trim();

    if (!reply) {
      return json({ error: 'The assistant had no answer for that. Try rephrasing?' }, 502);
    }

    return json({ reply });
  } catch (err) {
    // Never surface upstream error text — it can carry request details.
    console.error('Anthropic request failed:', err && err.message);
    const status = err && err.status === 429 ? 429 : 502;
    return json(
      {
        error:
          status === 429
            ? 'A lot of questions coming in at once. Give it a moment and try again.'
            : "Something went wrong on my end. Try again in a moment, or use the contact form and Jamie will get back to you.",
      },
      status
    );
  }
};

export const config = {
  path: '/api/chat',
};
