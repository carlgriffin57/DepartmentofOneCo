/*
 * Generates Pinterest pin images for departmentofone.co (1000x1500 PNG).
 *
 *   node src/pin-images.mjs
 *
 * Separate from the Open Graph cards on purpose. Pinterest only accepts
 * portrait or square (between 2:3 and 1:1) and rejects the 1200x630 OG card
 * outright; everywhere else — Facebook, LinkedIn, X, Slack, iMessage — wants
 * roughly 1.91:1. Two shapes, two files, both from the same tokens.
 *
 * These are for uploading to Pinterest by hand with the destination link set,
 * which gives control over the pin design and description that URL-scraping
 * does not. They are hosted so they can be grabbed from any device.
 *
 * Lives here because this is where the toolchain is installed — same as
 * graphics.mjs and og-images.mjs.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import opentype from 'opentype.js';
import sharp from 'sharp';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(HERE, '..', '..', 'assets', 'pin');
const CACHE = path.join(HERE, '.fonts');

// --- departmentofone.co tokens (assets/styles.css :root) --------------------
const PAPER = '#FBFAF7';
const INK = '#14171C';
const INK3 = '#6B7280';
const ACCENT = '#B07D2B';

const W = 1000;
const H = 1500; // 2:3 — Pinterest's recommended pin ratio
const M = 90;

/* Lines taken verbatim from the pages, matching the OG cards. */
const PINS = [
  { slug: 'home', line: 'Your entire digital department. One person.', kicker: 'San Antonio, Texas' },
  { slug: 'services', line: 'Fixed prices. No surprises.', kicker: 'Websites from $300' },
  { slug: 'about', line: 'One person, the whole job, a fair price.', kicker: '30+ years in software QA' },
  { slug: 'work', line: 'One build, start to finish.', kicker: 'See the work' },
  { slug: 'contact', line: 'Tell me what you’re working on.', kicker: 'Reply within one business day' },
];

const FONTS = {
  display: { file: 'fraunces-600.ttf', css: 'https://fonts.googleapis.com/css2?family=Fraunces:wght@600' },
  body: { file: 'inter-500.ttf', css: 'https://fonts.googleapis.com/css2?family=Inter:wght@500' },
};

const LEGACY_UA = 'Mozilla/5.0 (Windows NT 5.1)';

async function loadFont({ file, css }) {
  const cached = path.join(CACHE, file);
  try {
    return opentype.parse(toArrayBuffer(await fs.readFile(cached)));
  } catch { /* not cached */ }

  const sheet = await (await fetch(css, { headers: { 'User-Agent': LEGACY_UA } })).text();
  const url = sheet.match(/src:\s*url\((https:[^)]+)\)/)?.[1];
  if (!url) throw new Error(`No TTF URL for ${file}`);
  const bytes = Buffer.from(await (await fetch(url)).arrayBuffer());
  await fs.mkdir(CACHE, { recursive: true });
  await fs.writeFile(cached, bytes);
  return opentype.parse(toArrayBuffer(bytes));
}

const toArrayBuffer = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);

/* Glyph-by-glyph: opentype.js's string API throws on a Fraunces GSUB lookup
   ("substitutionType : 62 ... not yet supported"). Costs kerning only. */
const glyphAdvance = (font, ch, size) =>
  (font.charToGlyph(ch).advanceWidth * size) / font.unitsPerEm;

const widthOf = (font, text, size) =>
  [...text].reduce((w, ch) => w + glyphAdvance(font, ch, size), 0);

const n = (v) => {
  if (!Number.isFinite(v)) throw new Error(`Non-finite path coordinate: ${v}`);
  return Number(v.toFixed(2));
};

function toPathData(p) {
  const out = [];
  for (const c of p.commands) {
    switch (c.type) {
      case 'M': out.push(`M${n(c.x)} ${n(c.y)}`); break;
      case 'L': out.push(`L${n(c.x)} ${n(c.y)}`); break;
      case 'C': out.push(`C${n(c.x1)} ${n(c.y1)} ${n(c.x2)} ${n(c.y2)} ${n(c.x)} ${n(c.y)}`); break;
      case 'Q': out.push(`Q${n(c.x1)} ${n(c.y1)} ${n(c.x)} ${n(c.y)}`); break;
      case 'Z': out.push('Z'); break;
      default: throw new Error(`Unhandled path command: ${c.type}`);
    }
  }
  return out.join('');
}

function pathFor(font, text, size, x, y, fill) {
  let cx = x;
  const parts = [];
  for (const ch of text) {
    if (ch !== ' ') parts.push(`<path d="${toPathData(font.charToGlyph(ch).getPath(cx, y, size))}" fill="${fill}"/>`);
    cx += glyphAdvance(font, ch, size);
  }
  return parts.join('');
}

/* Uppercased and letterspaced by hand — SVG letter-spacing does not survive
   conversion to outlines. */
function tracked(font, text, size, x, y, fill, tracking) {
  let cx = x;
  const parts = [];
  for (const ch of text) {
    if (ch !== ' ') parts.push(`<path d="${toPathData(font.charToGlyph(ch).getPath(cx, y, size))}" fill="${fill}"/>`);
    cx += glyphAdvance(font, ch, size) + tracking;
  }
  return parts.join('');
}

function wrap(font, text, size, maxWidth) {
  const lines = [];
  let line = '';
  for (const word of text.split(' ')) {
    const next = line ? `${line} ${word}` : word;
    if (widthOf(font, next, size) > maxWidth && line) { lines.push(line); line = word; }
    else line = next;
  }
  if (line) lines.push(line);
  return lines;
}

/* A pin is seen small in a scrolling feed, so the headline should fill the
   frame. Start large and step down only as far as needed. */
function fitType(font, text, maxWidth, maxLines) {
  // The ceiling is high on purpose. A 2:3 frame is much taller than a 1.91:1
  // one, so type sized for the OG card leaves the middle of a pin empty.
  const words = text.split(' ');
  for (let size = 156; size >= 56; size -= 2) {
    // A size is only usable if the longest single word fits on a line.
    // Wrapping can only break between words, so anything wider than the
    // measure silently runs off the edge rather than wrapping.
    if (Math.max(...words.map((w) => widthOf(font, w, size))) > maxWidth) continue;
    const lines = wrap(font, text, size, maxWidth);
    if (lines.length <= maxLines) return { size, lines };
  }
  return { size: 56, lines: wrap(font, text, 56, maxWidth) };
}

function buildSvg(display, body, pin) {
  const maxWidth = W - M * 2;
  const { size, lines } = fitType(display, pin.line, maxWidth, 6);
  const lineHeight = size * 1.12;

  // Centred between the top rule and the footer rule, then lifted slightly —
  // a text block centred by arithmetic reads as sitting low.
  const bandTop = M + 130;
  const bandBottom = H - M - 130;
  const blockHeight = lines.length * lineHeight;
  const top = bandTop + (bandBottom - bandTop - blockHeight) / 2 + size * 0.74;

  const headline = lines
    .map((t, i) => pathFor(display, t, size, M, top + i * lineHeight, INK))
    .join('');

  const dotR = 10;
  const wordmark =
    `<circle cx="${M + dotR}" cy="${M + 6}" r="${dotR}" fill="${ACCENT}"/>` +
    pathFor(display, 'Department of One', 36, M + dotR * 2 + 16, M + 18, INK);

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <rect width="${W}" height="${H}" fill="${PAPER}"/>
  ${wordmark}
  <rect x="${M}" y="${M + 62}" width="96" height="5" rx="2.5" fill="${ACCENT}"/>
  ${headline}
  <rect x="${M}" y="${H - M - 96}" width="${W - M * 2}" height="1.5" fill="${ACCENT}" opacity="0.3"/>
  ${tracked(body, pin.kicker.toUpperCase(), 22, M, H - M - 50, ACCENT, 2.6)}
  ${pathFor(body, 'departmentofone.co', 26, M, H - M, INK3)}
</svg>`;
}

const [display, body] = await Promise.all([loadFont(FONTS.display), loadFont(FONTS.body)]);
await fs.mkdir(OUT, { recursive: true });

for (const pin of PINS) {
  const svg = buildSvg(display, body, pin);
  if (/NaN|Infinity|undefined/.test(svg)) throw new Error(`pin-${pin.slug}: malformed path data`);

  const info = await sharp(Buffer.from(svg))
    .png({ compressionLevel: 9, palette: true, quality: 90 })
    .toFile(path.join(OUT, `${pin.slug}.png`));
  console.log(`pin/${pin.slug}.png  ${info.width}x${info.height}  ${(info.size / 1024).toFixed(0)} KB`);
}
