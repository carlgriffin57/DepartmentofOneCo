/*
 * Generates the three Oak Street social graphics (1080x1080 PNG).
 *
 *   node src/graphics.mjs
 *
 * Colors and fonts come from the Oak Street site tokens, so the graphics
 * match the demo site by construction rather than by eye.
 *
 * The set deliberately mixes two treatments — two photo posts and one type
 * post — because three variations on a single idea reads as a template, not
 * as a brand. Same palette, same fonts, same wordmark across all three.
 *
 * Text is converted to vector outlines, so rendering does not depend on
 * Poppins or Open Sans being installed on the machine running this.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import opentype from 'opentype.js';
import sharp from 'sharp';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ASSETS = path.join(HERE, '..', 'assets');
const OUT = path.join(ASSETS, 'graphics');
// Web-sized copies for the main site's Work page.
const WEB_OUT = path.join(HERE, '..', '..', 'assets', 'graphics');
const CACHE = path.join(HERE, '.fonts');

// --- Oak Street site tokens -------------------------------------------------
const BG = '#F8FAFC';      // surface
const INK = '#0F172A';     // primary (navy)
const ACCENT = '#0369A1';  // cta (blue)
const LIGHT = '#FFFFFF';

const SIZE = 1080;
const MARGIN = 96;

// Final copy, trainer's voice. `photo` picks the treatment.
const TIPS = [
  {
    text: 'A tired dog is an easy dog. Most behavior problems are just unspent energy.',
    photo: 'hero-dog-1080.jpg',
  },
  {
    text: "Reward what you want. Ignore what you don't. Dogs repeat what pays off.",
  },
  {
    text: 'Five minutes a day beats an hour on Sunday. Consistency is the whole trick.',
    photo: 'trainer-jamie-1080.jpg',
  },
];

const FONTS = {
  poppins: {
    file: 'poppins-600.ttf',
    css: 'https://fonts.googleapis.com/css2?family=Poppins:wght@600',
  },
  openSans: {
    file: 'opensans-600.ttf',
    css: 'https://fonts.googleapis.com/css2?family=Open+Sans:wght@600',
  },
};

// Ask Google Fonts for the legacy TTF payload rather than woff2, which
// opentype.js cannot parse.
const LEGACY_UA = 'Mozilla/5.0 (Windows NT 5.1)';

async function loadFont({ file, css }) {
  const cached = path.join(CACHE, file);
  try {
    return opentype.parse(toArrayBuffer(await fs.readFile(cached)));
  } catch {
    /* not cached yet */
  }

  const sheet = await (await fetch(css, { headers: { 'User-Agent': LEGACY_UA } })).text();
  const url = sheet.match(/src:\s*url\((https:[^)]+)\)/)?.[1];
  if (!url) throw new Error(`Could not find a TTF URL for ${file}`);

  const bytes = Buffer.from(await (await fetch(url)).arrayBuffer());
  await fs.mkdir(CACHE, { recursive: true });
  await fs.writeFile(cached, bytes);
  return opentype.parse(toArrayBuffer(bytes));
}

function toArrayBuffer(buf) {
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
}

const widthOf = (font, text, size) => font.getAdvanceWidth(text, size);

/* Greedy wrap on whole words to a maximum pixel width. */
function wrap(font, text, size, maxWidth) {
  const lines = [];
  let line = '';
  for (const word of text.split(' ')) {
    const next = line ? `${line} ${word}` : word;
    if (widthOf(font, next, size) > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = next;
    }
  }
  if (line) lines.push(line);
  return lines;
}

/*
 * Serialize path commands to SVG `d` ourselves.
 *
 * opentype.js's own toPathData() emits literal "NaN" into the output for some
 * glyphs at some positions, even though every command value is finite. librsvg
 * then stops parsing at that point and the rest of the line silently vanishes.
 * Formatting the commands directly avoids the bug entirely.
 */
const n = (v) => {
  if (!Number.isFinite(v)) throw new Error(`Non-finite path coordinate: ${v}`);
  return Number(v.toFixed(2));
};

function toPathData(p) {
  const out = [];
  for (const c of p.commands) {
    switch (c.type) {
      case 'M': out.push(`M${n(c.x)} ${n(c.y)}`); break;
      case 'L': out.push(`L${n(c.x)} ${n(c.y)}`); break;
      case 'C': out.push(`C${n(c.x1)} ${n(c.y1)} ${n(c.x2)} ${n(c.y2)} ${n(c.x)} ${n(c.y)}`); break;
      case 'Q': out.push(`Q${n(c.x1)} ${n(c.y1)} ${n(c.x)} ${n(c.y)}`); break;
      case 'Z': out.push('Z'); break;
      default: throw new Error(`Unhandled path command: ${c.type}`);
    }
  }
  return out.join('');
}

const pathFor = (font, text, size, x, y, fill) =>
  `<path d="${toPathData(font.getPath(text, x, y, size))}" fill="${fill}"/>`;

/* Open Sans wordmark, uppercased and letterspaced by hand — SVG letter-spacing
   does not survive conversion to outlines. */
function trackedWordmark(font, text, size, x, y, fill, tracking) {
  let cursor = x;
  const parts = [];
  for (const ch of text) {
    if (ch !== ' ') parts.push(pathFor(font, ch, size, cursor, y, fill));
    cursor += widthOf(font, ch, size) + tracking;
  }
  return parts.join('');
}

/*
 * Fit the tip to the square by stepping the type size down until it wraps to
 * at most `maxLines`. Starting large and shrinking to fit means the type fills
 * the frame instead of floating in the middle of it — the thing that made the
 * first version read as unfinished.
 */
function fitType(font, text, maxWidth, maxLines) {
  for (let size = 104; size >= 60; size -= 2) {
    const lines = wrap(font, text, size, maxWidth);
    if (lines.length <= maxLines) return { size, lines };
  }
  return { size: 60, lines: wrap(font, text, 60, maxWidth) };
}

function buildSvg(poppins, openSans, tip, onPhoto) {
  const maxWidth = SIZE - MARGIN * 2;
  const { size, lines } = fitType(poppins, tip.text, maxWidth, 4);
  const lineHeight = size * 1.24;

  const ink = onPhoto ? LIGHT : INK;
  const rule = onPhoto ? LIGHT : ACCENT;

  // Sit the block slightly above centre so it reads with the wordmark rather
  // than floating between the two rules.
  const blockHeight = lines.length * lineHeight;
  const top = (SIZE - blockHeight) / 2 + size * 0.3;

  const tipSvg = lines
    .map((line, i) => pathFor(poppins, line, size, MARGIN, top + i * lineHeight, ink))
    .join('');

  // A photo needs a scrim for the type to stay legible over any part of it.
  const scrim = onPhoto
    ? `<rect width="${SIZE}" height="${SIZE}" fill="${INK}" fill-opacity="0.78"/>`
    : `<rect width="${SIZE}" height="${SIZE}" fill="${BG}"/>`;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${SIZE}" height="${SIZE}" viewBox="0 0 ${SIZE} ${SIZE}">
  ${scrim}
  <rect x="${MARGIN}" y="${MARGIN + 18}" width="88" height="5" rx="2.5" fill="${rule}"/>
  ${tipSvg}
  <rect x="${MARGIN}" y="${SIZE - MARGIN - 62}" width="${SIZE - MARGIN * 2}" height="1.5" fill="${rule}" opacity="${onPhoto ? 0.5 : 0.28}"/>
  ${trackedWordmark(openSans, 'OAK STREET DOG TRAINING', 25, MARGIN, SIZE - MARGIN, ink, 3.4)}
</svg>`;
}

const [poppins, openSans] = await Promise.all([loadFont(FONTS.poppins), loadFont(FONTS.openSans)]);
await fs.mkdir(OUT, { recursive: true });

for (const [i, tip] of TIPS.entries()) {
  const num = i + 1;
  const svg = buildSvg(poppins, openSans, tip, Boolean(tip.photo));

  // A malformed coordinate makes librsvg drop the rest of the line silently,
  // so fail loudly here instead of shipping a half-rendered graphic.
  if (/NaN|Infinity|undefined/.test(svg)) {
    throw new Error(`tip-${num}: malformed path data in generated SVG`);
  }

  await fs.writeFile(path.join(OUT, `tip-${num}.svg`), svg);

  const png = path.join(OUT, `tip-${num}.png`);
  const overlay = Buffer.from(svg);

  const info = tip.photo
    ? await sharp(path.join(ASSETS, tip.photo))
        .resize(SIZE, SIZE, { fit: 'cover' })
        .composite([{ input: overlay, top: 0, left: 0 }])
        .png({ compressionLevel: 9 })
        .toFile(png)
    : await sharp(overlay).png({ compressionLevel: 9 }).toFile(png);

  // The 1080 PNG is the social deliverable. The Work page shows these at about
  // 380px, so it gets a 640 WebP instead — the full PNGs are ~2MB together,
  // which is absurd for thumbnails.
  const webInfo = await sharp(png)
    .resize(640, 640)
    .webp({ quality: 82 })
    .toFile(path.join(WEB_OUT, `tip-${num}.webp`));

  console.log(
    `tip-${num}  ${info.width}x${info.height} ${(info.size / 1024).toFixed(0)}KB png` +
    `  ·  640 ${(webInfo.size / 1024).toFixed(0)}KB webp  ·  ${tip.photo ? 'photo' : 'type'}`
  );
}
