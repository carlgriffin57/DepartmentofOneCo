/*
 * Generates the Open Graph share images for departmentofone.co (1200x630 PNG).
 *
 *   node src/og-images.mjs
 *
 * Lives here rather than at the repo root because this is where the toolchain
 * (sharp, opentype.js) is installed — the same reason graphics.mjs writes the
 * main site's social thumbnails from this directory. Output goes to the main
 * site's assets/og/.
 *
 * Built from the site's own tokens and fonts, so a shared link looks like the
 * page it points at. Text is converted to vector outlines, so rendering does
 * not depend on Fraunces or Inter being installed locally.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import opentype from 'opentype.js';
import sharp from 'sharp';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(HERE, '..', '..', 'assets', 'og');
const CACHE = path.join(HERE, '.fonts');

// --- departmentofone.co tokens (assets/styles.css :root) --------------------
const PAPER = '#FBFAF7';
const INK = '#14171C';
const INK3 = '#6B7280';
const ACCENT = '#B07D2B';

const W = 1200;
const H = 630;
const M = 80;

/* One card per page. `line` is taken verbatim from the page it represents. */
const PAGES = [
  { slug: 'home', line: 'Your entire digital department. One person.' },
  { slug: 'services', line: 'Fixed prices. No surprises.' },
  { slug: 'about', line: 'One person, the whole job, a fair price.' },
  { slug: 'work', line: 'One build, start to finish.' },
  { slug: 'contact', line: 'Tell me what you’re working on.' },
];

const FONTS = {
  display: { file: 'fraunces-600.ttf', css: 'https://fonts.googleapis.com/css2?family=Fraunces:wght@600' },
  body: { file: 'inter-500.ttf', css: 'https://fonts.googleapis.com/css2?family=Inter:wght@500' },
};

const LEGACY_UA = 'Mozilla/5.0 (Windows NT 5.1)';

async function loadFont({ file, css }) {
  const cached = path.join(CACHE, file);
  try {
    return opentype.parse(toArrayBuffer(await fs.readFile(cached)));
  } catch { /* not cached */ }

  const sheet = await (await fetch(css, { headers: { 'User-Agent': LEGACY_UA } })).text();
  const url = sheet.match(/src:\s*url\((https:[^)]+)\)/)?.[1];
  if (!url) throw new Error(`No TTF URL for ${file} — Google Fonts may not serve a static build`);

  const bytes = Buffer.from(await (await fetch(url)).arrayBuffer());
  await fs.mkdir(CACHE, { recursive: true });
  await fs.writeFile(cached, bytes);
  return opentype.parse(toArrayBuffer(bytes));
}

const toArrayBuffer = (b) => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);

/*
 * Measure and draw one glyph at a time.
 *
 * opentype.js's string-level API (getPath / getAdvanceWidth) runs the OpenType
 * feature engine, which throws on Fraunces:
 *   "substitutionType : 62 lookupType: 6 - substFormat: 2 is not yet supported"
 * Going through charToGlyph skips that engine entirely. The cost is kerning and
 * ligatures, which at display size on a share card is not a visible loss.
 */
const glyphAdvance = (font, ch, size) =>
  (font.charToGlyph(ch).advanceWidth * size) / font.unitsPerEm;

const widthOf = (font, text, size) =>
  [...text].reduce((w, ch) => w + glyphAdvance(font, ch, size), 0);

function wrap(font, text, size, maxWidth) {
  const lines = [];
  let line = '';
  for (const word of text.split(' ')) {
    const next = line ? `${line} ${word}` : word;
    if (widthOf(font, next, size) > maxWidth && line) { lines.push(line); line = word; }
    else line = next;
  }
  if (line) lines.push(line);
  return lines;
}

/* opentype.js's own toPathData() emits literal "NaN" for some glyphs at some
   positions; librsvg then silently drops the rest of the line. Same bug that
   truncated the Oak Street graphics — serialise the commands directly. */
const n = (v) => {
  if (!Number.isFinite(v)) throw new Error(`Non-finite path coordinate: ${v}`);
  return Number(v.toFixed(2));
};

function toPathData(p) {
  const out = [];
  for (const c of p.commands) {
    switch (c.type) {
      case 'M': out.push(`M${n(c.x)} ${n(c.y)}`); break;
      case 'L': out.push(`L${n(c.x)} ${n(c.y)}`); break;
      case 'C': out.push(`C${n(c.x1)} ${n(c.y1)} ${n(c.x2)} ${n(c.y2)} ${n(c.x)} ${n(c.y)}`); break;
      case 'Q': out.push(`Q${n(c.x1)} ${n(c.y1)} ${n(c.x)} ${n(c.y)}`); break;
      case 'Z': out.push('Z'); break;
      default: throw new Error(`Unhandled path command: ${c.type}`);
    }
  }
  return out.join('');
}

function pathFor(font, text, size, x, y, fill) {
  let cx = x;
  const parts = [];
  for (const ch of text) {
    if (ch !== ' ') {
      parts.push(`<path d="${toPathData(font.charToGlyph(ch).getPath(cx, y, size))}" fill="${fill}"/>`);
    }
    cx += glyphAdvance(font, ch, size);
  }
  return parts.join('');
}

/* Step the headline down until it fits in at most `maxLines`. */
function fitType(font, text, maxWidth, maxLines) {
  for (let size = 86; size >= 46; size -= 2) {
    const lines = wrap(font, text, size, maxWidth);
    if (lines.length <= maxLines) return { size, lines };
  }
  return { size: 46, lines: wrap(font, text, 46, maxWidth) };
}

function buildSvg(display, body, line) {
  const maxWidth = W - M * 2;
  const { size, lines } = fitType(display, line, maxWidth, 3);
  const lineHeight = size * 1.16;

  // Headline block sits between the wordmark and the footer rule.
  const top = 300 - ((lines.length - 1) * lineHeight) / 2;
  const headline = lines
    .map((t, i) => pathFor(display, t, size, M, top + i * lineHeight, INK))
    .join('');

  // The wordmark repeats on every card — that is the point of the exercise.
  const dotR = 9;
  const wordmark =
    `<circle cx="${M + dotR}" cy="${M + 4}" r="${dotR}" fill="${ACCENT}"/>` +
    pathFor(display, 'Department of One', 32, M + dotR * 2 + 14, M + 15, INK);

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <rect width="${W}" height="${H}" fill="${PAPER}"/>
  ${wordmark}
  ${headline}
  <rect x="${M}" y="${H - M - 46}" width="${W - M * 2}" height="1.5" fill="${ACCENT}" opacity="0.3"/>
  ${pathFor(body, 'departmentofone.co', 24, M, H - M, INK3)}
</svg>`;
}

const [display, body] = await Promise.all([loadFont(FONTS.display), loadFont(FONTS.body)]);
await fs.mkdir(OUT, { recursive: true });

for (const { slug, line } of PAGES) {
  const svg = buildSvg(display, body, line);
  if (/NaN|Infinity|undefined/.test(svg)) throw new Error(`og-${slug}: malformed path data`);

  const info = await sharp(Buffer.from(svg)).png({ compressionLevel: 9, palette: true, quality: 90 })
    .toFile(path.join(OUT, `${slug}.png`));
  console.log(`og/${slug}.png  ${info.width}x${info.height}  ${(info.size / 1024).toFixed(0)} KB`);
}
