/*
 * Regenerates the Oak Street photographic assets for the web.
 *
 *   node src/images.mjs
 *
 * Source files live OUTSIDE the repo (they are large originals, not worth
 * committing). Update SOURCES if they move. The generated files in
 * assets/ are committed so deploys stay build-free.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';

const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'assets');

const SOURCES = [
  {
    // Hero: golden retriever. Already square, so the crop is a no-op.
    src: 'C:/Users/carlg/Digital Marketing/Website services/medium-sized-dog-portrait.png',
    name: 'hero-dog',
    // `attention` keeps the highest-interest region when cropping to square.
    position: sharp.strategy.attention,
  },
  {
    // About section: Jamie, the trainer. Carl reframed this one square with
    // both faces in shot, so it drops into the square slot untouched — no
    // crop, nothing lost.
    src: 'C:/Users/carlg/Digital Marketing/Website services/jaime with dog.png',
    name: 'trainer-jamie',
  },
];

// Both slots render at roughly 540px wide at the largest breakpoint, so 1080
// covers 2x displays. 640 serves smaller screens without the extra weight.
const WIDTHS = [1080, 640];

for (const { src, name, position, crop } of SOURCES) {
  if (!fs.existsSync(src)) {
    console.error(`SKIP ${name}: source not found at ${src}`);
    continue;
  }
  for (const w of WIDTHS) {
    for (const [fmt, ext, opts] of [
      ['webp', 'webp', { quality: 82, effort: 5 }],
      ['jpeg', 'jpg', { quality: 82, mozjpeg: true }],
    ]) {
      const file = path.join(OUT, `${name}-${w}.${ext}`);
      let pipeline = sharp(src);
      if (crop) pipeline = pipeline.extract(crop);
      const info = await pipeline
        .resize(w, w, { fit: 'cover', position: position ?? 'centre' })
        [fmt](opts)
        .toFile(file);
      console.log(`${path.basename(file).padEnd(26)} ${info.width}x${info.height}  ${(info.size / 1024).toFixed(0)} KB`);
    }
  }
}
