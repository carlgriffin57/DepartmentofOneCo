/* Oak Street Dog Training — demo site behavior.
   The contact form is deliberately client-side only: it runs no live
   infrastructure, sends nothing, and stores nothing. */
(function () {
  'use strict';

  var form = document.getElementById('consult-form');
  var thanks = document.getElementById('consult-thanks');
  var nameOut = document.getElementById('consult-name');
  var reset = document.getElementById('consult-reset');
  if (!form || !thanks) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    // Let the browser report missing required fields rather than silently
    // showing a success state for an empty form.
    if (typeof form.reportValidity === 'function' && !form.reportValidity()) return;

    var typed = (form.elements.name && form.elements.name.value || '').trim();
    if (nameOut) {
      // First name only, and set as text so a pasted name can never inject markup.
      nameOut.textContent = typed ? typed.split(/\s+/)[0] : 'there';
    }

    form.classList.add('hidden');
    thanks.classList.remove('hidden');
    // Move focus to the confirmation so screen-reader and keyboard users
    // land on the new content instead of a hidden form.
    thanks.setAttribute('tabindex', '-1');
    thanks.focus();
  });

  if (reset) {
    reset.addEventListener('click', function () {
      form.reset();
      thanks.classList.add('hidden');
      form.classList.remove('hidden');
      var first = form.querySelector('input, select, textarea');
      if (first) first.focus();
    });
  }
})();
