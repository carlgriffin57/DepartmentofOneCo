/* Oak Street Dog Training — chat client.
   Talks only to /api/chat. The Anthropic API key lives in a Netlify
   environment variable and is never sent to the browser. */
(function () {
  'use strict';

  var form = document.getElementById('chat-form');
  var input = document.getElementById('chat-input');
  var log = document.getElementById('chat-log');
  var send = document.getElementById('chat-send');
  var sendLabel = document.getElementById('chat-send-label');
  var suggestions = document.getElementById('chat-suggestions');
  if (!form || !input || !log || !send) return;

  // Conversation history sent to the server each turn. The system prompt lives
  // server-side, so it can't be edited or read from here.
  var history = [];
  var MAX_TURNS = 20;
  var busy = false;

  var PAW = '<svg class="w-4 h-4 text-cta" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4.5 6.375a4.125 4.125 0 1 1 8.25 0 4.125 4.125 0 0 1-8.25 0ZM14.25 8.625a3.375 3.375 0 1 1 6.75 0 3.375 3.375 0 0 1-6.75 0ZM1.5 19.125a7.125 7.125 0 0 1 14.25 0v.003l-.001.119a.75.75 0 0 1-.363.63 13.067 13.067 0 0 1-6.761 1.873c-2.472 0-4.786-.684-6.76-1.873a.75.75 0 0 1-.364-.63l-.001-.122Z"/></svg>';

  function scrollDown() {
    log.scrollTop = log.scrollHeight;
  }

  /* Renders one message. Text is always assigned via textContent, so model
     output and user input can never inject markup. */
  function addMessage(role, text) {
    var wrap = document.createElement('div');
    var bubble = document.createElement('div');
    var p = document.createElement('p');
    p.textContent = text;

    if (role === 'user') {
      wrap.className = 'flex justify-end';
      bubble.className = 'bg-cta text-white rounded-2xl rounded-br-sm px-4 py-3 max-w-[85%]';
      p.className = 'leading-relaxed';
      bubble.appendChild(p);
      wrap.appendChild(bubble);
    } else {
      wrap.className = 'flex gap-3';
      var avatar = document.createElement('div');
      avatar.className = 'w-8 h-8 rounded-full bg-blue-50 flex-shrink-0 flex items-center justify-center';
      avatar.setAttribute('aria-hidden', 'true');
      avatar.innerHTML = PAW;
      bubble.className = 'bg-surface rounded-2xl rounded-tl-sm px-4 py-3 max-w-[85%]';
      p.className = 'text-secondary leading-relaxed whitespace-pre-wrap';
      bubble.appendChild(p);
      wrap.appendChild(avatar);
      wrap.appendChild(bubble);
    }

    log.appendChild(wrap);
    scrollDown();
    return wrap;
  }

  function addTyping() {
    var wrap = document.createElement('div');
    wrap.className = 'flex gap-3';
    wrap.setAttribute('data-typing', 'true');
    wrap.innerHTML =
      '<div class="w-8 h-8 rounded-full bg-blue-50 flex-shrink-0 flex items-center justify-center" aria-hidden="true">' + PAW + '</div>' +
      '<div class="bg-surface rounded-2xl rounded-tl-sm px-4 py-3"><span class="sr-only">Typing</span>' +
      '<span class="flex gap-1" aria-hidden="true">' +
      '<span class="w-2 h-2 bg-slate-300 rounded-full animate-pulse"></span>' +
      '<span class="w-2 h-2 bg-slate-300 rounded-full animate-pulse"></span>' +
      '<span class="w-2 h-2 bg-slate-300 rounded-full animate-pulse"></span>' +
      '</span></div>';
    log.appendChild(wrap);
    scrollDown();
    return wrap;
  }

  function setBusy(state) {
    busy = state;
    send.disabled = state;
    input.disabled = state;
    if (sendLabel) sendLabel.textContent = state ? 'Sending' : 'Send';
  }

  function autoGrow() {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  }
  input.addEventListener('input', autoGrow);

  // Enter sends; Shift+Enter makes a new line.
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  if (suggestions) {
    suggestions.addEventListener('click', function (e) {
      var btn = e.target.closest('.chat-suggestion');
      if (!btn || busy) return;
      input.value = btn.textContent.trim();
      autoGrow();
      form.requestSubmit();
    });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (busy) return;

    var text = input.value.trim();
    if (!text) return;

    addMessage('user', text);
    history.push({ role: 'user', content: text });
    if (history.length > MAX_TURNS) history = history.slice(-MAX_TURNS);

    input.value = '';
    autoGrow();
    if (suggestions) suggestions.remove();
    setBusy(true);
    var typing = addTyping();

    fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: history }),
    })
      .then(function (res) {
        return res.json().then(function (data) {
          return { ok: res.ok, status: res.status, data: data };
        });
      })
      .then(function (r) {
        typing.remove();
        if (!r.ok || !r.data || !r.data.reply) {
          var msg =
            r.status === 429
              ? "A lot of questions coming in at once. Give it a moment and try again."
              : (r.data && r.data.error) ||
                "Something went wrong on my end. Try again in a moment, or use the contact form and Jamie will get back to you.";
          addMessage('assistant', msg);
          return;
        }
        addMessage('assistant', r.data.reply);
        history.push({ role: 'assistant', content: r.data.reply });
        if (history.length > MAX_TURNS) history = history.slice(-MAX_TURNS);
      })
      .catch(function () {
        typing.remove();
        addMessage(
          'assistant',
          "I couldn't reach the server. Check your connection and try again, or use the contact form and Jamie will get back to you."
        );
      })
      .finally(function () {
        setBusy(false);
        input.focus();
      });
  });
})();
