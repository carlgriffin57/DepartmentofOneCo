# n8n — booking form to Notion

`oakstreet-booking-workflow.json` is the automation behind the Work page's
"Booking automation" card: a form submission arrives on a webhook and lands as a
row in the **Booking Requests** database, with no manual step.

Four nodes:

```
Booking form webhook  →  Normalize fields  →  Create Booking Request  →  Respond 200
```

---

## Setup

- [ ] **Import.** n8n → Workflows → `···` → **Import from File**
- [ ] **Set the credential.** Open *Create Booking Request* → pick your Notion
      integration. If you have not made one: Notion → Settings → Connections →
      Develop or manage integrations → new internal integration → copy the secret.
- [ ] **Share the database with the integration.** In Notion, open **Booking
      Requests** → `···` → **Connections** → add your integration.
      Skipping this gives `object_not_found` even though the ID is correct —
      the API cannot see a database that has not been shared with it.
- [ ] **Pick the database from the list — do not paste an ID.** In
      *Create Booking Request*, switch the **Database** field from **By ID** to
      **From list** and select **Booking Requests**.

      > The JSON ships with an ID placeholder, but pasting an ID is the slow way
      > to get this wrong. An **inline** database has no ID of its own — copying
      > the URL of the page it sits on gives you the *parent page* ID, which
      > looks perfectly valid and silently points at the wrong thing. Symptom:
      > property option lookups fail with an unhelpful error. **From list**
      > avoids the whole class of problem.

- [ ] **Check the property mappings.** Open the node and confirm each of the six
      rows resolved to a real property. n8n stores these as `Name|type` pairs —
      if a name or type does not match your database, the row shows as unset and
      you re-pick it from the dropdown. Worth a look rather than an assumption.
- [ ] **If `Status` will not load its options,** hover its **Option Name or ID**
      field, switch it to **Expression**, and type `New`.

      > n8n fails to populate that dropdown even against the correct database
      > (`Cannot read properties of undefined (reading 'split')`). The failure is
      > in building the picker, not in writing the value — an expression sends
      > the string straight through and the row lands with `Status = New`.
      > Confirmed working; treat the error as cosmetic.
- [ ] **Activate**, then copy the **Production URL** from the webhook node.

## Point the local form at it

Do **not** change the deployed demo — that form is deliberately inert and the
site says so. Work on a local copy:

```bash
cp index.html /tmp/oakstreet-local.html
```

In the copy, change the form tag:

```html
<form id="consult-form" method="POST" action="http://localhost:5678/webhook/oakstreet-booking">
```

and delete the `<script src="/assets/site.js">` line, so the browser submits
normally instead of the demo's client-side handler intercepting it.

## Test before filming

PowerShell (`curl` there is an alias for `Invoke-WebRequest` and will reject
curl's flags — use this instead):

```powershell
Invoke-RestMethod -Uri http://localhost:5678/webhook/oakstreet-booking -Method Post -ContentType 'application/json' -Body '{"name":"Test Row","email":"test@example.com","phone":"210-555-0100","service":"Basic Obedience","message":"Delete me."}'
```

bash:

```bash
curl -X POST http://localhost:5678/webhook/oakstreet-booking -H 'Content-Type: application/json' -d '{"name":"Test Row","email":"test@example.com","phone":"210-555-0100","service":"Basic Obedience","message":"Delete me."}'
```

Expect `ok: True` with an id, and a new row carrying **all seven** fields — title,
email, phone, Program, Message, Status `New`, Received today. A row that arrives
with `Program` or `Status` blank means the value did not match an existing
option.

**Delete the test row before you record.** Then submit through the actual form
once — the request proves the workflow, the form proves the whole path.

---

## Two things built in on purpose

**The program guard.** The *Normalize fields* node checks the incoming `service`
value against the seven exact program names and falls back to `Not sure yet` if
it does not match:

```
Puppy Foundation · Basic Obedience · Behavior Correction
In-Home Private · Group Classes · Board & Train · Not sure yet
```

Unlike CSV import, the **n8n Notion node does not create missing select
options**. Without this guard a typo produces a successful run with an empty
Program field — a silent failure, and an easy one to miss while filming.

**Open CORS.** The webhook sets `allowedOrigins: "*"` so a local HTML file can
post to it. Without that the browser blocks the preflight and the form appears to
do nothing, with the error only visible in the console. **Restrict this before
using the workflow for anything real.**

## Field names

Straight from the demo form, so the mapping needs no translation:

| Form field | Notion property | Type |
|---|---|---|
| `name` | Name | Title |
| `email` | Email | Email |
| `phone` | Phone | Phone |
| `service` | Program | Select |
| `message` | Message | Text |
| — | Status | Select — set to `New` |
| — | Received | Date — set to today |

## If it fails

| Symptom | Cause |
|---|---|
| `object_not_found` | Database not shared with the integration, or wrong ID |
| `Cannot read properties of undefined (reading 'split')` on a property's options | Either the Database field points at a parent page rather than the database (use **From list**), or the known `Status` picker bug — set the value as an **Expression** |
| Node opens the wrong database in the browser | You pasted a parent page ID. Switch the Database field to **From list** |
| Row created, Program empty | Value is not one of the seven — check the guard survived import |
| Row created, Status empty | The option does not exist on the property, or a near-duplicate was created (`New` vs `New Request`). Delete the unused option in Notion |
| Row created, Received empty | `Received` is a *Created time* property; it must be **Date** |
| Form does nothing, console shows CORS | Webhook not active, or `allowedOrigins` lost on import |
| 404 on the webhook URL | Using the Test URL after it expired — use the Production URL and activate |
| PowerShell rejects the test command | `curl` is aliased to `Invoke-WebRequest`. Use the `Invoke-RestMethod` form above |

> Property numbering in the node UI (`Property 1, 2, 4, 7…`) never renumbers
> after a delete. Cosmetic; nothing references those labels.
