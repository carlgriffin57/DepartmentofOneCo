/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './chat.html', './assets/*.js'],
  theme: {
    extend: {
      fontFamily: {
        heading: ['Poppins', 'sans-serif'],
        body: ['Open Sans', 'sans-serif'],
      },
      colors: {
        primary: '#0F172A',
        secondary: '#334155',
        cta: '#0369A1',
        'cta-hover': '#0284C7',
        surface: '#F8FAFC',
        text: '#020617',
        muted: '#475569',
      },
      // The markup uses numeric weight classes (font-500 / font-600 / font-700).
      // Tailwind ships only named weights, so without these the classes emit no
      // CSS and every heading and button renders at normal weight. Registering
      // the numerics makes the existing markup render as it was written to.
      fontWeight: {
        300: '300',
        400: '400',
        500: '500',
        600: '600',
        700: '700',
      },
    },
  },
  plugins: [],
};
